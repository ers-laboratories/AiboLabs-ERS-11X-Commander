import { createBoard } from '@wixc3/react-board';
import styles from './main-menu-selector.board.module.scss';
import classNames from 'classnames';
import styles0 from './game-mode.board.module.scss';
import KickSvg from '../../assets/kick.svg';
import ArrowUpSvg from '../../assets/arrow_up.svg';
import LeftSvg from '../../assets/left.svg';
import RightSvg from '../../assets/right.svg';
import TurnOffSvg from '../../assets/turn_off.svg';
import PickupSvg from '../../assets/pickup.svg';
import DownSvg from '../../assets/down.svg';
import PlaceItemSvg from '../../assets/place_item.svg';
import DislikeSvg from '../../assets/dislike.svg';
import TrackSvg from '../../assets/track.svg';
import LikePlusSvg from '../../assets/like_plus.svg';
import HomeSvg from '../../assets/home.svg';
import TurnOnSvg from '../../assets/turn_on.svg';

export default createBoard({
    name: 'GameMode',
    Board: () => (
        <div className={styles.div1}>
            <div className={styles.first_block}>
                <div className={styles0.div9}>
                    <div className={styles0.div11}>
                        <button className={styles0.button1}>
                            <img src={HomeSvg} alt="" className={styles0.img1} />
                        </button>
                    </div>
                    <div className={styles0.div12}>
                        <button className={classNames(styles0.button1, styles0.Turn_on_button)}>
                            <img src={TurnOnSvg} alt="" className={styles0.img1} />
                        </button>
                    </div>
                    <div className={styles0.div13}>
                        <button className={classNames(styles0.button1, styles0.Turn_off_button)}>
                            <img src={TurnOffSvg} alt="" className={styles0.img1} />
                        </button>
                    </div>
                </div>
            </div>
            <div className={styles.second_block}>Game Mode</div>
            <div className={styles.third_block}>
                <div className={styles0.GameModeButtonsGrid}>
                    <div className={styles0.div1}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>K-Left</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={KickSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles.div2}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>Left</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={LeftSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles.div3}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>Pickup </div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={PickupSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles.div4}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>Lose</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={DislikeSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles.div5}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>Forward</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={ArrowUpSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles0.div2}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>Stop</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={TurnOffSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles0.div3}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>Backward</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={DownSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles0.div4}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>Track</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={TrackSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles0.div5}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>K-Right</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={KickSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles0.div6}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>Right</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={RightSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles0.div7}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>Release</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={PlaceItemSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                    <div className={styles0.div8}>
                        <div className={styles0.inner_grid}>
                            <div className={styles0.inner_grid_button_name}>Win</div>
                            <div className={styles0.inner_grid_button_sound}>
                                <button className={styles0.button1}>
                                    <img src={LikePlusSvg} alt="" className={styles0.img1} />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    ),
    isSnippet: true,
    environmentProps: {
        windowWidth: 437,
        windowHeight: 915,
    },
});
