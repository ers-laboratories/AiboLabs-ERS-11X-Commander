import { createBoard } from '@wixc3/react-board';
import styles from './main-menu-selector.board.module.scss';
import classNames from 'classnames';

export default createBoard({
    name: 'main_menu_selector',
    Board: () => (
        <div className={styles.div1}>
            <div className={styles.first_block}>AiboLabs ERS 11X Commander</div>
            <div className={styles.second_block}>
                <div className={styles.left_logo}></div>
                <div className={styles.logo_div}>
                    <div className={styles.right_logo}></div>
                </div>
            </div>
            <div className={styles.third_block}>
                <div className={styles.menu_grid}>
                    <div className={styles.div2}>
                        <button className={styles.button1}>Standard Mode</button>
                    </div>
                    <div className={styles.div3}>
                        <button className={styles.button1} onClick={undefined}>
                            Game Mode
                        </button>
                    </div>
                    <div className={styles.div4}>
                        <button className={styles.button1}>Performance Mode</button>
                    </div>
                    <div className={styles.div5}></div>
                </div>
            </div>
        </div>
    ),
    isSnippet: true,
    environmentProps: {
        windowWidth: 430,
        windowHeight: 932,
    },
});
